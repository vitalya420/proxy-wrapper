from proxy_wrapper.proxied_socket import ProxiedSocket
from proxy_wrapper.utils import parse_proxy_string


def wrap_socket(sock, *proxy_strings):
    proxied = sock if isinstance(sock, ProxiedSocket) else ProxiedSocket.from_socket(sock)
    for proxy_string in proxy_strings:
        proxied.add_proxy(parse_proxy_string(proxy_string))
    return proxied
