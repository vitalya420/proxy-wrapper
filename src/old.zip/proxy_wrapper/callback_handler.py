from functools import wraps, partial
from typing import Dict, Any, Callable

from proxy_wrapper.exceptions import WantWriteError, UnfinishedJobException, WantReadError


class CallbacksHandler(Dict[Any, Callable]):
    _singleton = None

    def __new__(cls, *args: Any, **kwargs: Any) -> "CallbacksHandler":
        if cls._singleton is None:
            cls._singleton = super().__new__(cls)
        return cls._singleton

    def __call__(self, func):
        @wraps(func)
        def inner(*args, **kwargs):
            try:
                if callback := self.get(func):
                    self.pop(func)
                    return callback()
                return func(*args, **kwargs)
            except UnfinishedJobException as e:
                self[func] = e.callback
                if e.exception:
                    raise e.exception
                raise

        return inner


callbacks_handler = CallbacksHandler()


def read_safe(func):
    @wraps(func)
    def inner(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except BlockingIOError:
            raise UnfinishedJobException(
                callback=partial(func, *args, **kwargs),
                exception=WantReadError(f"Function {func.__name__} is not ready yet"),
            )

    return inner


def write_safe(func):
    @wraps(func)
    def inner(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except BlockingIOError:
            raise UnfinishedJobException(
                callback=partial(func, *args, **kwargs),
                exception=WantWriteError(),
            )

    return inner
