import socket
from typing import Tuple, Callable

from proxy_wrapper.callback_handler import read_safe, write_safe
from proxy_wrapper.mixins.socks5.enums import ATYP
from proxy_wrapper.mixins.socks5.exceptions import ProxyAuthenticationError, ProxyError
import proxy_wrapper.mixins.socks5.helper as socks5_helper


class Socks5SocketMixin(socket.socket):
    def socks5_connect(self, addr: Tuple[str, int], on_completed: Callable | None = None):
        """
        Send SOCKS5 connect message.
        """
        message = socks5_helper.request_to_connect_to_remote_address(addr)
        initial_reply = b""

        @write_safe
        def send_connect():
            nonlocal message
            self.send(message.to_bytes())
            check_connect_reply()

        @read_safe
        def check_connect_reply():
            nonlocal initial_reply, addr
            initial_reply = self.recv(4)
            if len(initial_reply) < 4:
                raise ValueError("Incomplete SOCKS5 reply header received.")
            atyp = ATYP(initial_reply[3])
            if atyp == ATYP.IPV4:
                return read_remaining(6)
            elif atyp == ATYP.DOMAIN_NAME:
                return read_domain_len()
            elif atyp == ATYP.IPV6:
                return read_remaining(18)
            else:
                raise ValueError("Invalid address type.")

        @read_safe
        def read_domain_len():
            domain_length_byte = self.recv(1)
            domain_length = domain_length_byte[0] if domain_length_byte else 0
            return read_remaining(1 + domain_length + 2)

        @read_safe
        def read_remaining(size: int):
            nonlocal initial_reply
            remaining_data = self.recv(size)
            full_reply = initial_reply + remaining_data
            reply = socks5_helper.loads_reply(full_reply)
            nonlocal addr
            if reply.is_ok():
                nonlocal on_completed
                if on_completed:
                    on_completed()
            else:
                raise ProxyError("Error occurred during connection.")

        send_connect()

    def socks5_hello(self, credentials: Tuple[str, str] | None, on_completed: Callable | None = None):
        """
        Send SOCKS5 hello message and perform authentication if credentials are provided.
        """
        hello_message = socks5_helper.craft_hello_message(credentials)
        credentials_message = socks5_helper.craft_username_password_message(*credentials) if credentials else None

        @write_safe
        def send_hello():
            nonlocal hello_message
            self.send(hello_message.to_bytes())
            read_hello_response()

        @read_safe
        def read_hello_response():
            res = socks5_helper.loads_hello_response(self.recv(2))
            res.raise_exception_if_occurred()
            if res.requires_credentials():
                provide_credentials()
            else:
                call_callback()

        @write_safe
        def provide_credentials():
            nonlocal credentials_message
            self.send(credentials_message.to_bytes())
            check_auth_reply()

        @read_safe
        def check_auth_reply():
            reply_bytes = self.recv(2)
            reply = socks5_helper.loads_authentication_response(reply_bytes)
            if not reply.is_ok():
                raise ProxyAuthenticationError("Authentication failed.")
            call_callback()

        def call_callback():
            nonlocal on_completed
            if on_completed:
                on_completed()

        send_hello()
