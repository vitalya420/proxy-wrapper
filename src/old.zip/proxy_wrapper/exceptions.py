from typing import Callable


class ProxyWrapperException(Exception):
    def __init__(self, message: str = ""):
        super().__init__(message)


class WantReadError(ProxyWrapperException):
    pass


class WantWriteError(ProxyWrapperException):
    pass


class UnfinishedJobException(ProxyWrapperException):
    def __init__(self, callback: Callable, exception: Exception):
        self.callback = callback
        self.exception = exception
