import socket
from collections import deque
from functools import partial
from queue import Queue

from proxy_wrapper.callback_handler import callbacks_handler
from proxy_wrapper.enums import ProxySocketState, ProxyProtocol
from proxy_wrapper.exceptions import UnfinishedJobException, WantWriteError, WantReadError
from proxy_wrapper.mixins import Socks5SocketMixin
from proxy_wrapper.proxy import Proxy


class ProxiedSocket(Socks5SocketMixin):
    def __init__(self, family=-1, type=-1, proto=-1, fileno=None):
        super().__init__(family, type, proto, fileno)

        self.proxy_chain: deque[Proxy] = deque()
        self.proxy_queue: Queue[Proxy] = Queue()
        self.state: ProxySocketState = ProxySocketState.INITIALIZED

    @classmethod
    def from_socket(cls, sock: socket.socket):
        proxied = cls(sock.family, sock.type, sock.proto, sock.fileno())
        proxied.setblocking(sock.getblocking())
        sock.detach()
        return proxied

    def add_proxy(self, proxy: Proxy):
        self.proxy_queue.put(proxy)

    @callbacks_handler
    def connect(self, address, /):
        if self.state == ProxySocketState.IN_COMMAND_MODE:
            if self.last_in_chain_protocol == ProxyProtocol.SOCKS5:
                self.socks5_connect(address)
        return super().connect(address)

    def _on_connected(self, proxy: Proxy):
        self.proxy_chain.append(proxy)
        self.state = ProxySocketState.IN_COMMAND_MODE

        if proxy.protocol == ProxyProtocol.SOCKS5:
            self.socks5_hello(proxy.credentials, on_completed=self.raise_callback_non_blocking_mode)
            # The code below will be reached only in blocking mode
            # And only if proxy authorization was success

    def _perform_connection_to_proxy(self, proxy: Proxy):
        try:
            self.connect(proxy.address)
            self._on_connected(proxy)
        except BlockingIOError:
            raise UnfinishedJobException(
                callback=partial(self._on_connected, proxy),
                exception=WantWriteError(),
            )
        except (WantWriteError, WantReadError) as e:
            raise UnfinishedJobException(callback=partial(self._perform_connection_to_proxy, proxy), exception=e)

    @callbacks_handler
    def perform_connection_non_blocking(self):
        if not self.all_proxy_connections_completed:
            proxy = self.proxy_queue.get()
            self.proxy_queue.task_done()
            self._perform_connection_to_proxy(proxy)
        self.raise_next_connection_callback()

    def perform_connection_blocking(self):
        while not self.proxy_queue.empty():
            proxy = self.proxy_queue.get()
            self.proxy_queue.task_done()
            self._perform_connection_to_proxy(proxy)

    def perform_connection(self):
        self.perform_connection_blocking() if self.getblocking() else self.perform_connection_non_blocking()

        @property
        def all_proxy_connections_completed(self):
            return self.proxy_queue.empty()

    @property
    def last_in_chain_protocol(self) -> ProxyProtocol:
        return self.proxy_chain[-1].protocol

    def raise_next_connection_callback(self):
        if not self.all_proxy_connections_completed:
            proxy = self.proxy_queue.get()
            raise UnfinishedJobException(
                callback=partial(self._perform_connection_to_proxy, proxy),
                exception=WantWriteError(),
            )

    def raise_callback_non_blocking_mode(self):
        if not self.getblocking() and not self.all_proxy_connections_completed:
            self.raise_next_connection_callback()
