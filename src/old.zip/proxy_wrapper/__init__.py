
def print_hello():
    print("Hello from proxy_wrapper!")