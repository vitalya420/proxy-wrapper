from functools import wraps

from proxy_wrapper.exceptions import UnfinishedJobException, WantWriteError, WantReadError
from .exception import _UncompletedRecv, _UncompletedWrite

checkpoints = {}


def continuable_function(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            if callback := checkpoints.get(func):
                checkpoints.pop(func)
                return callback()
            return func(*args, **kwargs)
        except _UncompletedRecv as e:
            checkpoints[func] = e.callback_to_continue
            raise UnfinishedJobException(callback=e.callback_to_continue, exception=WantReadError(
                f"Function {func.__name__} wants to read but io was not ready yet"))
        except _UncompletedWrite as e:
            checkpoints[func] = e.callback_to_continue
            raise UnfinishedJobException(callback=e.callback_to_continue, exception=WantWriteError(
                f"Function {func.__name__} wants to write but io was not ready yet"))

    return wrapper
