import socket


class HttpSocketMixin(socket.socket):
    """
    Mixin that implements proxying via http(s) proxy protocol
    """

    def send_http_handshake(self, credentials = None):
        print("Sending http handshake")