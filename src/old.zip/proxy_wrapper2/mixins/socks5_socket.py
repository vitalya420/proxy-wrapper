import socket
from typing import Tuple, Callable

import proxy_wrapper.mixins.socks5.helper as socks5_helper
from proxy_wrapper.mixins.socks5.enums import ATYP
from proxy_wrapper.mixins.socks5.exceptions import ProxyAuthenticationError, ProxyError
from proxy_wrapper2.decorators import recv_non_blocking


class Socks5SocketMixin(socket.socket):
    """
    Mixin that implements proxying via socks5 protocol
    """

    def _handshake_blocking(self, credentials: tuple[str, int] | None = None):
        hello_message = socks5_helper.craft_hello_message(credentials)
        auth_message = socks5_helper.craft_username_password_message(*credentials) if credentials else None

        self.send(hello_message.to_bytes())
        reply = socks5_helper.loads_hello_response(self.recv(2))

        if reply.requires_credentials():
            self.send(auth_message.to_bytes())
            reply = socks5_helper.loads_authentication_response(self.recv(2))
            if not reply.is_ok():
                raise ProxyAuthenticationError("Authentication failed.")
        return True

    def _handshake_nonblocking(self, credentials: tuple[str, int] | None = None,
                               non_blocking_callback: Callable | None = None):
        hello_message = socks5_helper.craft_hello_message(credentials)
        auth_message = socks5_helper.craft_username_password_message(*credentials) if credentials else None

        def send_hello():
            nonlocal hello_message
            self.send(hello_message.to_bytes())
            print(f'[*] nonblocking socks5 hello sent: {hello_message}')
            read_reply()

        @recv_non_blocking
        def read_reply():
            reply = socks5_helper.loads_hello_response(self.recv(2))
            if reply.requires_credentials():
                provide_credentials()

            print(f'[*] nonblocking socks5 handshake completed: {reply}')
            nonlocal non_blocking_callback
            if non_blocking_callback:
                non_blocking_callback()

        def provide_credentials():
            raise NotImplementedError("Later...")

        send_hello()

    def send_socks5_handshake(self, credentials: tuple[str, int] | None = None,
                              non_blocking_callback: Callable | None = None):
        # print("Sending socks5 hello")
        if self.getblocking():
            return self._handshake_blocking(credentials)
        return self._handshake_nonblocking(credentials, non_blocking_callback)

    def socks5_connect(self, address: Tuple[str, int]):
        if self.getblocking():
            return self._socks5_connect_blocking(address)
        return self._socks5_connect_nonblocking(address)

    def _socks5_connect_nonblocking(self, address: Tuple[str, int], on_completed: Callable | None = None):
        connect_message = socks5_helper.request_to_connect_to_remote_address(address)
        initial_reply = b""

        def send_connect():
            nonlocal connect_message
            self.send(connect_message.to_bytes())
            print("[*] nonblocking socks5 connect sent", connect_message, )
            check_connect_reply()

        @recv_non_blocking
        def check_connect_reply():
            nonlocal initial_reply, address
            initial_reply = self.recv(4)
            print(f"[*] nonblocking socks5 initial reply received: {initial_reply}")
            if len(initial_reply) < 4:
                raise ValueError("Incomplete SOCKS5 reply header received.")
            atyp = ATYP(initial_reply[3])
            if atyp == ATYP.IPV4:
                return read_remaining(6)
            elif atyp == ATYP.DOMAIN_NAME:
                return read_domain_len()
            elif atyp == ATYP.IPV6:
                return read_remaining(18)
            else:
                raise ValueError("Invalid address type.")

        @recv_non_blocking
        def read_domain_len():
            domain_length_byte = self.recv(1)
            domain_length = domain_length_byte[0] if domain_length_byte else 0
            return read_remaining(1 + domain_length + 2)

        @recv_non_blocking
        def read_remaining(size: int):
            nonlocal initial_reply
            remaining_data = self.recv(size)
            full_reply = initial_reply + remaining_data
            reply = socks5_helper.loads_reply(full_reply)

            print(f"[*] nonblocking socks5 reply received: {reply}")
            nonlocal address
            if reply.is_ok():
                nonlocal on_completed
                if on_completed:
                    on_completed()
            else:
                raise ProxyError("Error occurred during connection.")

        send_connect()

    def _socks5_connect_blocking(self, address):
        connect_message = socks5_helper.request_to_connect_to_remote_address(address)
        print("sending socks5 connect message:", connect_message)
        self.send(connect_message.to_bytes())
        initial_reply = self.recv(4)
        print("Nigga initial reply:", initial_reply)

        if len(initial_reply) < 4:
            raise ValueError("Incomplete SOCKS5 reply header received.")
        atyp = ATYP(initial_reply[3])
        if atyp == ATYP.IPV4:
            remaining_data = self.recv(6)
        elif atyp == ATYP.DOMAIN_NAME:
            domain_length_byte = self.recv(1)
            domain_length = domain_length_byte[0] if domain_length_byte else 0
            remaining_data = self.recv(1 + domain_length + 2)
        elif atyp == ATYP.IPV6:
            remaining_data = self.recv(6)
        else:
            raise ValueError("Invalid address type.")

        full_reply = initial_reply + remaining_data
        reply = socks5_helper.loads_reply(full_reply)
        # print(reply)
