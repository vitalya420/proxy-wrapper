import socket


class Socks4SocketMixin(socket.socket):
    """
    Mixin that implements proxying via socks4 protocol
    """
    def send_socks4_handshake(self, credentails: tuple[str, int] = None):
        print("Sending socks4 hello")