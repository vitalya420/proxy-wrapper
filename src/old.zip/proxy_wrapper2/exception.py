from typing import Callable


class ProxyWrapperException(Exception):
    pass


class _UncompletedWrite(ProxyWrapperException):
    def __init__(self, callback_to_continue: Callable, message: str):
        self.callback_to_continue = callback_to_continue
        self.message = message


class _UncompletedRecv(ProxyWrapperException):
    def __init__(self, callback_to_continue: Callable, message: str):
        self.callback_to_continue = callback_to_continue
        self.message = message
        super().__init__(message)