from logging import getLogger


logger = getLogger("proxy_wrapper2")

logger.info("logger initialized")