import socket
from collections import deque
from functools import partial
from queue import Queue

from proxy_wrapper.enums import ProxySocketState, ProxyProtocol
from proxy_wrapper.exceptions import WantWriteError, UnfinishedJobException, WantReadError
from proxy_wrapper.proxy import Proxy
from proxy_wrapper2.decorators import unfinished_handler2
from proxy_wrapper2.exception import _UncompletedRecv
from proxy_wrapper2.mixins import Socks5SocketMixin, Socks4SocketMixin, HttpSocketMixin


class NonBlockedProxiedSocketMixin(HttpSocketMixin, Socks4SocketMixin, Socks5SocketMixin):
    def __init__(self, family=-1, type=-1, proto=-1, fileno=None):
        super().__init__(family, type, proto, fileno)

        self.proxy_chain: deque[Proxy] = deque()
        self.proxy_queue: Queue[Proxy] = Queue()
        self.state: ProxySocketState = ProxySocketState.INITIALIZED

        self._next_callback = None

    # def _connect_according_to_proxy_protocol(self, address):
    #     last_in_chain_protocol = self.proxy_chain[-1].protocol if self.proxy_chain else None
    #
    #     print(f"Fucking nigger connect to {address}", self.state)
    #     if last_in_chain_protocol is None:
    #         raise RuntimeError("Fuck you Error")
    #     if last_in_chain_protocol == ProxyProtocol.SOCKS5:
    #         return self.socks5_connect(address)

    def connect(self, address, /):

        if self.state == ProxySocketState.IN_COMMAND_MODE:
            try:
                return self._connect_according_to_proxy_protocol(address)
            except _UncompletedRecv as e:
                print(address)
                raise
        return super().connect(address)

    def on_handshake_completed(self, proxy: Proxy):
        print("handshake completed to proxy: ", proxy)
        self.proxy_chain.append(proxy)
        self.state = ProxySocketState.IN_COMMAND_MODE
        self.raise_callback_non_blocking_mode()

    def on_connected_to_proxy(self, proxy: Proxy):
        print("Sending handshake to proxy: ", proxy)
        if proxy.protocol == ProxyProtocol.SOCKS5:
            self.send_socks5_handshake(proxy.credentials, partial(self.on_handshake_completed, proxy))

    def connect_to_proxy_non_blocking(self, proxy: Proxy):
        print("Connect to proxy", proxy)
        try:
            self.connect(proxy.address)
        except BlockingIOError:
            raise UnfinishedJobException(
                callback=partial(self.on_connected_to_proxy, proxy),
                exception=WantWriteError(),
            )
        except _UncompletedRecv as e:
            def _continue_connecting(cb):
                cb()
                # self.on_connected_to_proxy(proxy)

            raise UnfinishedJobException(
                callback=partial(_continue_connecting, e.callback_to_continue),
                exception=WantReadError()
            )

    def perform_connection_to_next_proxy_non_blocking(self):

        try:
            if self._next_callback:
                self._next_callback()
                self._next_callback = None
                return
            self.raise_callback_non_blocking_mode()
        except UnfinishedJobException as e:
            print("[i] Next callback is", e.callback)
            self._next_callback = e.callback
            raise e.exception
        except _UncompletedRecv as e:
            print("[i] Next callback is", e.callback_to_continue)
            self._next_callback = e.callback_to_continue
            raise WantReadError()

    def check_connected(self):
        try:
            self.getpeername()
            return True
        except OSError:
            return False

    @property
    def all_proxy_connections_completed(self):
        return self.proxy_queue.empty()

    def raise_next_connection_callback(self):
        if not self.all_proxy_connections_completed:
            raise UnfinishedJobException(
                callback=partial(self.connect_to_proxy_non_blocking, self.proxy_queue.get_nowait()),
                exception=WantWriteError(),
            )

    def raise_callback_non_blocking_mode(self):
        if not self.getblocking() and not self.all_proxy_connections_completed:
            self.raise_next_connection_callback()
