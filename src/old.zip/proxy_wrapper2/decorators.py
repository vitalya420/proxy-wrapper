from collections.abc import Callable
from functools import partial, wraps
from typing import Dict

from proxy_wrapper.exceptions import UnfinishedJobException, WantReadError
from proxy_wrapper2.exception import _UncompletedRecv


# def recv_non_blocking(func: Callable):
#     def wrapper(*args, **kwargs):
#         try:
#             return func(*args, **kwargs)
#         except BlockingIOError:
#             print(
#                 f"{func.__name__} called .recv() but io was not ready yet. Call callback "
#                 f"to recall this function"
#             )
#             raise _UncompletedRecv(message=f"{func.__name__} called .recv() but io was not ready yet. Call callback "
#                                            f"to recall this function",
#                                    callback_to_continue=partial(func, *args, **kwargs))
#
#     return wrapper


class UnfinishedHandler(Dict[Callable, Callable]):
    _singleton = None

    def __new__(cls, *args, **kwargs):
        if cls._singleton is None:
            cls._singleton = super().__new__(cls)
        return cls._singleton

    def __call__(self, func: Callable):
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                if self.get(func) is not None:
                    cb = self.pop(func)
                    print('[i] instead of calling ', func.__name__, ' we call ', cb)
                    return cb()
                return func(*args, **kwargs)
            except UnfinishedJobException as e:
                # print(f"Function {func.__name__} has unfinished job. Callback is {e.callback}")
                self[func] = e.callback
                if e.exception:
                    raise e.exception
                raise RuntimeError("Unfinished job has no exception")

        return wrapper


unfinished_handler = UnfinishedHandler()


class UnfinishedHandler2(Dict[Callable, Callable]):
    _singleton = None

    def __new__(cls, *args, **kwargs):
        if cls._singleton is None:
            cls._singleton = super().__new__(cls)
        return cls._singleton

    def __call__(self, func: Callable):
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                if cb := self.get(func):
                    self.pop(func)
                    return cb()
                return func(*args, **kwargs)
            except UnfinishedJobException as e:
                self[func] = e.callback
                if e.exception:
                    raise e.exception
                raise
            except _UncompletedRecv as e:
                self[func] = e.callback_to_continue
                raise WantReadError(e.message)
        return wrapper


unfinished_handler2 = UnfinishedHandler2()
