import socket
from collections import deque
from functools import partial
from queue import Queue

from proxy_wrapper.enums import ProxyProtocol, ProxySocketState
from proxy_wrapper.exceptions import UnfinishedJobException, WantWriteError
from proxy_wrapper.proxy import Proxy
from .decorators import unfinished_handler2
from .non_blocked import NonBlockedProxiedSocketMixin


class ProxiedSocket(NonBlockedProxiedSocketMixin):
    def __init__(self, family=-1, type=-1, proto=-1, fileno=None):
        super().__init__(family, type, proto, fileno)

        self._non_blocking_callback = None
        self._on_connected_callback = None

    @classmethod
    def from_socket(cls, sock: socket.socket):
        instance = cls(sock.family, sock.type, sock.proto, sock.fileno())
        instance.setblocking(sock.getblocking())
        return instance

    def _connect_according_to_proxy_protocol(self, address):
        last_in_chain_protocol = self.proxy_chain[-1].protocol if self.proxy_chain else None

        if last_in_chain_protocol is None:
            raise RuntimeError("Fuck you Error")
        print(f"Fucking nigger connect to {address}", self.state)
        if last_in_chain_protocol == ProxyProtocol.SOCKS5:
            return self.socks5_connect(address)
        # elif last_in_chain_protocol == ProxyProtocol.SOCKS4:
        #     return self.socks4_connect(address)
        # elif last_in_chain_protocol in (ProxyProtocol.HTTP, ProxyProtocol.HTTPS):
        #     return self.http_connect(address)
        else:
            raise ValueError("Unknown proxy protocol")

    # def connect(self, address, /):
    #     if self.state == ProxySocketState.IN_COMMAND_MODE:
    #         # print("Connecting via proxy to address", address)
    #         return self._connect_according_to_proxy_protocol(address)
    #     return super().connect(address)

    def _do_proxy_handshake(self, proxy: Proxy):
        def _non_blocking_callback():
            nonlocal proxy
            print(f'[i] non-blocking handshake completed with {proxy.address}')
            self.proxy_chain.append(proxy)
            self.state = ProxySocketState.IN_COMMAND_MODE
            self.raise_callback_non_blocking_mode()

        if proxy.protocol == ProxyProtocol.SOCKS5:
            # print("Doing proxy handshake!!! Socks5")
            self.send_socks5_handshake(proxy.credentials, _non_blocking_callback)
        elif proxy.protocol == ProxyProtocol.SOCKS4:
            self.send_socks4_handshake(proxy.credentials)
        elif proxy.protocol in (ProxyProtocol.HTTP, ProxyProtocol.HTTPS):
            self.send_http_handshake(proxy.credentials)
        else:
            raise ValueError("Unknown proxy protocol")

    def _on_connected_to_proxy(self, proxy: Proxy):
        if self._on_connected_callback:
            try:
                self._on_connected_callback()
                self._on_connected_callback = None
                return
            except UnfinishedJobException as e:
                self._on_connected_callback = e.callback
                raise e.exception

        try:
            print(f"[i] Starting handshake with proxy {proxy.address}")
            self._do_proxy_handshake(proxy)
            print("Handshake completed.")
            self.proxy_chain.append(proxy)
            self.state = ProxySocketState.IN_COMMAND_MODE
        except UnfinishedJobException as e:
            self._on_connected_callback = e.callback
            raise UnfinishedJobException(callback=partial(self._on_connected_to_proxy, proxy), exception=e.exception)

    def _connect_to_proxy(self, proxy: Proxy):
        try:
            self.connect(proxy.address)
            self._on_connected_to_proxy(proxy)
        except BlockingIOError:
            raise UnfinishedJobException(
                callback=partial(self._on_connected_to_proxy, proxy),
                exception=WantWriteError(),
            )
        # except UnfinishedJobException as e:
        #     e.callback = partial(self._connect_to_proxy, proxy)
        #     raise e

    def add_proxy(self, proxy: Proxy, *, perform_connection: bool | None = None):
        if perform_connection is not None:
            if self.getblocking():
                return self._connect_to_proxy(proxy)
            raise NotImplementedError("Non-blocking mode is not supported yet")
        self.proxy_queue.put(proxy)

    def _perform_connection_blocking(self):
        while not self.proxy_queue.empty():
            proxy = self.proxy_queue.get_nowait()
            self._connect_to_proxy(proxy)
            self.proxy_queue.task_done()

    @unfinished_handler2
    def _perform_connection_non_blocking(self):
        print("Nigga shit!!")
        self.raise_callback_non_blocking_mode()
        # if self._non_blocking_callback:
        #     try:
        #         self._non_blocking_callback()
        #         self._non_blocking_callback = None
        #         return
        #     except UnfinishedJobException as e:
        #         self._non_blocking_callback = e.callback
        #         raise e.exception
        #
        # try:
        #     self._connect_to_proxy(self.proxy_queue.get())
        # except UnfinishedJobException as e:
        #     self._non_blocking_callback = e.callback
        #     raise e.exception
        # finally:
        #     self.proxy_queue.task_done()

        # print("[i] Performing non-blocking connection")
        # try:
        #     self.raise_callback_non_blocking_mode()
        # except UnfinishedJobException as e:
        #     print("[i] Next callback is", e.callback)
        #     raise

        # if self._non_blocking_callback:
        #     try:
        #         self._non_blocking_callback()
        #         self._non_blocking_callback = None
        #         return
        #     except UnfinishedJobException as e:
        #         self._non_blocking_callback = e.callback
        #         raise e.exception
        #
        # print(f"Performing non-blocking connection to proxy. State: {self.state}. Empty: {self.proxy_queue.empty()}")
        #
        # if self.state == ProxySocketState.INITIALIZED and not self.proxy_queue.empty():
        #     proxy = self.proxy_queue.get_nowait()
        #     print(f"Connecting to first proxy in queue: {proxy.address}")
        #     try:
        #         self._connect_to_proxy(proxy)
        #     except UnfinishedJobException as e:
        #         self._non_blocking_callback = e.callback
        #         raise e.exception
        # self.raise_callback_non_blocking_mode()

        # if self.state == ProxySocketState.INITIALIZED:
        #     try:
        #         proxy = self.proxy_queue.get_nowait()
        #         print("Let's connect to first proxy in queue", proxy)
        #         self.proxy_queue.task_done()
        #         self._connect_to_proxy(proxy)
        #     except queue.Empty:
        #         if not self.proxy_chain:
        #             raise RuntimeError(
        #                 f"No proxy in queue. No need to use {self.__class__.__name__}. Use socket.socket() instead. "
        #                 f"This behavior is not supported yet and will be changed in the future.")
        #         else:
        #             print("Connection to proxy completed.")
        # else:
        #     self.raise_callback_non_blocking_mode()

    def perform_connection(self):
        if self.getblocking():
            return self._perform_connection_blocking()
        return super().perform_connection_to_next_proxy_non_blocking()
        # raise NotImplementedError("Non-blocking mode is not supported yet")


